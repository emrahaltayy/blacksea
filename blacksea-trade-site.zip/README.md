# BLACKSEA TRADE

Run locally:
```bash
npm install
npm run dev
```
Then open http://localhost:3000